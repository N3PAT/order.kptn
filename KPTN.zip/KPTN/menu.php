<?php
session_start();
include 'includes/db.php'; 

// ตรวจสอบการล็อกอิน
if (!isset($_SESSION['user_id'])) {
    // ถ้าไม่มีการล็อกอิน ให้ส่งผู้ใช้ไปยังหน้า login
    header("Location: login.php");
    exit();
}

// ดึงข้อมูลผู้ใช้จาก session
$user_id = $_SESSION['user_id'];
$query = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

// ชื่อผู้ใช้
$username = $user['full_name'];
$points = $user['points'];

if (isset($_POST['add_to_cart'])) {
    $menu_item = $_POST['menu_item'];
    $price = $_POST['price'];
    $extras = $_POST['extra'] ?? [];
    $note = $_POST['note'] ?? '';

    $query = "SELECT extra_allowed FROM menu WHERE name = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $menu_item);
    $stmt->execute();
    $result = $stmt->get_result();
    $item = $result->fetch_assoc();

    $extra_desc = '';
    $extra_list = [];

    if ($item && $item['extra_allowed'] == 1 && !empty($extras)) {
        foreach ($extras as $extra) {
            $price += 10;
            $extra_desc .= '+ ' . $extra . ' ';
            $extra_list[] = $extra;
        }
    }

    $key = $menu_item . $extra_desc;

    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }

    if (isset($_SESSION['cart'][$key])) {
        $_SESSION['cart'][$key]['quantity']++;
    } else {
        $_SESSION['cart'][$key] = [
            'name' => $menu_item,
            'extra' => $extra_list,
            'extra_desc' => trim($extra_desc),
            'price' => $price,
            'quantity' => 1,
            'note' => $note
        ];
    }

}

// การลบสินค้าออกจากตะกร้า
if (isset($_POST['remove_from_cart'])) {
    $item_to_remove = $_POST['remove_item'];
    if (isset($_SESSION['cart'][$item_to_remove])) {
        unset($_SESSION['cart'][$item_to_remove]);
    }
}

// จำนวนสินค้าทั้งหมดในตะกร้า
$total_items_in_cart = 0;
if (isset($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item) {
        $total_items_in_cart += $item['quantity'];
    }
}


// ดึงสถานะร้าน
$status_query = "SELECT * FROM store_status ORDER BY id DESC LIMIT 1";
$status_result = $conn->query($status_query);

if ($status_result && $status_result->num_rows > 0) {
    $store_status = $status_result->fetch_assoc();
    $is_open = (int)$store_status['is_open'];
    $reopen_time = $store_status['reopen_datetime'];

    if ($reopen_time) {
        date_default_timezone_set('Asia/Bangkok');
        $now = new DateTime();
        $reopen = new DateTime($reopen_time);
        $interval = $now->diff($reopen);
        $minutes_left = ($interval->days * 24 * 60) + ($interval->h * 60) + $interval->i;
        $formatted_reopen_time = $reopen->format('H:i น.');
    }
} else {
    $is_open = 1; // ร้านเปิดตามค่าเริ่มต้น
}
?>
<?php
// คำนวณเวลาคงเหลือ ถ้าร้านปิดและมีเวลา reopen
$secondsLeft = 0;
if (!$is_open && !empty($reopen_time)) {
    date_default_timezone_set('Asia/Bangkok');
    $now = new DateTime();
    $reopen = new DateTime($reopen_time);
    $secondsLeft = max(0, $reopen->getTimestamp() - $now->getTimestamp());
}
?>
<?php
function formatThaiDateTime($datetime_str) {
    $days = ['อาทิตย์','จันทร์','อังคาร','พุธ','พฤหัสบดี','ศุกร์','เสาร์'];
    $months = [1=>'มกราคม','กุมภาพันธ์','มีนาคม','เมษายน','พฤษภาคม','มิถุนายน',
               'กรกฎาคม','สิงหาคม','กันยายน','ตุลาคม','พฤศจิกายน','ธันวาคม'];

    $timestamp = strtotime($datetime_str);
    $thai_day = $days[date('w', $timestamp)];
    $thai_date = date('j', $timestamp);
    $thai_month = $months[date('n', $timestamp)];
    $thai_year = date('Y', $timestamp) + 543;
    $thai_time = date('H:i', $timestamp);

    return "วัน$thai_dayที่ $thai_date $thai_month $thai_year เวลา $thai_time น.";
}

$formatted_reopen_time = formatThaiDateTime($reopen_time);
?>
<!DOCTYPE html>
<html lang="th">
  
<head>
  
    <meta charset="UTF-8">
    <title>เมนูอาหาร</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <link href="https://fonts.googleapis.com/css2?family=Prompt:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.2/dist/sweetalert2.min.css">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <style>
        body {
            font-family: 'Prompt', sans-serif;
            background-color: #f8f9fa;
        }

        .menu-item {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            padding: 15px;
            transition: 0.3s;
        }

        .menu-item:hover {
            transform: translateY(-3px);
        }

        .menu-item img {
            width: 100px;
            height: 100px;
            object-fit: cover;
            border-radius: 8px;
            margin-right: 15px;
        }

        .menu-item h4 {
            margin-bottom: 5px;
        }

        .menu-item p {
            margin-bottom: 8px;
            color: #555;
        }

        .menu-item button {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 6px 12px;
            border-radius: 6px;
            font-weight: 500;
        }

        .out-of-stock {
            background-color: red;
            color: white;
            font-weight: bold;
            padding: 5px;
            border-radius: 5px;
        }

        .filter-section {
            margin: 20px 0;
        }

        .navbar {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
        }

        .navbar a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .cart-count {
            background-color: red;
            border-radius: 50%;
            padding: 5px 10px;
            color: white;
            font-weight: bold;
            position: absolute;
            top: 5px;
            right: 5px;
        }
input.form-control::placeholder {
    color: #aaa;
}

.input-group .btn {
    border-top-left-radius: 0;
    border-bottom-left-radius: 0;
}
        @media (max-width: 576px) {
            .menu-item {
                flex-direction: column;
                align-items: flex-start;
            }

            .menu-item img {
                margin: 0 0 10px 0;
            }
        }
    </style>
</head>

<body>
<script>
let secondsLeft = <?php echo $secondsLeft; ?>;

if (secondsLeft > 0) {
  function formatTime(seconds) {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    return `${h > 0 ? h + ' ชม ' : ''}${m > 0 ? m + ' นาที ' : ''}${s} วินาที`;
  }

  Swal.fire({
    title: 'ร้านปิดชั่วคราว',
    html: `ร้านจะเปิดอีกครั้ง <?php echo $formatted_reopen_time; ?><br>` +
          `กรุณารออีกประมาณ <span id="countdown">${formatTime(secondsLeft)}</span>`,
    icon: 'warning',
    showConfirmButton: false,
    allowOutsideClick: false,
    allowEscapeKey: false,
    allowEnterKey: false,
    willOpen: () => {
      const timerSpan = Swal.getHtmlContainer().querySelector('#countdown');
      const timerInterval = setInterval(() => {
        secondsLeft--;
        if (secondsLeft <= 0) {
          clearInterval(timerInterval);
          Swal.close();
          location.reload(); // โหลดหน้าใหม่อัตโนมัติหลังร้านเปิด
        } else {
          timerSpan.textContent = formatTime(secondsLeft);
        }
      }, 1000);
    }
  });
}
</script>
<nav class="navbar">
    <div class="container d-flex justify-content-between">
        <a href="menu.php" class="navbar-brand">เมนูอาหาร</a>
        <div class="user-info">
            สวัสดี, <?php echo htmlspecialchars($username); ?> | <a href="logout.php">ออกจากระบบ</a>
        </div>
        <div class="points">
            <span>พอยต์ของคุณ: <?php echo $points; ?> คะแนน</span>
        </div>
        <a href="cart.php" class="position-relative">
            <i class="fas fa-shopping-cart" style="font-size: 24px;"></i>
            <?php if ($total_items_in_cart > 0) { ?>
                <span class="cart-count"><?php echo $total_items_in_cart; ?></span>
            <?php } ?>
        </a>
    </div>
</nav>

<div class="container mt-4">
    <h2 class="text-center mb-4"><i class="fas fa-utensils"></i> เมนูอาหาร</h2>
<div class="row mb-4">
    <div class="col-md-6 offset-md-3">
        <form method="GET" action="" class="input-group">
            <input type="text" class="form-control" name="search" placeholder="ค้นหาเมนูอาหาร..." value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
            <div class="input-group-append">
                <button class="btn btn-primary" type="submit"><i class="fas fa-search"></i> ค้นหา</button>
            </div>
        </form>
    </div>
</div>
    <div class="row" id="menuList">
        <?php
$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
if (!empty($search)) {
    $query = "SELECT * FROM menu WHERE status='available' AND name LIKE '%$search%'";
} else {
    $query = "SELECT * FROM menu WHERE status='available'";
}
        $result = $conn->query($query);
        while ($row = $result->fetch_assoc()):
            $name = $row['name'] ?? '';
            $description = $row['description'] ?? 'ไม่มีรายละเอียดเพิ่มเติม';
            $price = $row['price'] ?? 0;
            $out_of_stock = $row['out_of_stock'] == 1; // เช็คสถานะของหมด
            $extra_allowed = $row['extra_allowed']; // เช็คว่าเมนูนี้สามารถมี extra ได้หรือไม่
        ?>
<div class="col-md-6 col-lg-4 mb-4">
    <div class="card shadow-sm h-100">
        <div class="card-body d-flex flex-column">
            <div class="d-flex align-items-center mb-3">
                <img src="assets/food.jpg" alt="..." class="rounded mr-3" style="width:80px;height:80px;object-fit:cover;">
                <div>
                    <h5 class="card-title mb-1"><?php echo htmlspecialchars($name); ?></h5>
                    <p class="text-muted mb-0"><?php echo $price; ?> บาท</p>
                </div>
            </div>
            <div class="mt-auto d-flex justify-content-between align-items-center">
                <?php if ($out_of_stock): ?>
                    <span class="badge badge-danger px-3 py-2">ของหมด</span>
                <?php else: ?>
                    <button type="button" class="btn btn-sm btn-primary"
                        onclick="openAddToCartModal('<?php echo addslashes($name); ?>',
                                                    '<?php echo addslashes($description); ?>',
                                                    '<?php echo $price; ?>',
                                                    <?php echo $extra_allowed ? 'true' : 'false'; ?>)">
                        <i class="fas fa-cart-plus"></i> สั่งเลย
                    </button>
                <?php endif; ?>
                <button class="btn btn-sm btn-outline-info" onclick="showDetails('<?php echo addslashes($name); ?>', '<?php echo addslashes($description); ?>')">
                    <i class="fas fa-info-circle"></i> รายละเอียด
                </button>
            </div>
        </div>
    </div>
</div>
        <?php endwhile; ?>
    </div>

</div>

<script>
    // ฟังก์ชันแสดงรายละเอียดของเมนู
    function showDetails(name, description) {
        Swal.fire({
            title: name,
            text: description,
            icon: 'info',
            confirmButtonText: 'ปิด'
        });
    }

function openAddToCartModal(name, description, price, allowExtra) {
    $('#modalTitle').text(name);
    $('#modalDescription').text(description);
    $('#modalPrice').text(price);
    $('#modalItemName').val(name);
    $('#modalPriceValue').val(price);
    
    if (allowExtra) {
        $('#modalExtras').show();
    } else {
        $('#modalExtras').hide();
    }

    $('#note').val('');
    $('#addToCartModal').modal('show');
}
</script>

<!-- Modal เพิ่มลงตะกร้า -->
<div class="modal" id="addToCartModal">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" action="">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalTitle">ชื่อเมนู</h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <div class="modal-body">
                    <p id="modalDescription"></p>

<input type="hidden" id="modalItemName" name="menu_item">
<input type="hidden" id="modalPriceValue" name="price">
<div id="modalExtras" class="mt-2">
    <div class="form-check">
        <input class="form-check-input" type="checkbox" name="extra[]" value="พิเศษ" id="extra1">
        <label class="form-check-label" for="extra1">พิเศษ (+10 บาท)</label>
    </div>
    <div class="form-check">
        <input class="form-check-input" type="checkbox" name="extra[]" value="ไข่ดาว" id="extra2">
        <label class="form-check-label" for="extra2">เพิ่มไข่ดาว (+10 บาท)</label>
    </div>
    <div class="form-check">
        <input class="form-check-input" type="checkbox" name="extra[]" value="ไข่เจียว" id="extra3">
        <label class="form-check-label" for="extra3">เพิ่มไข่เจียว (+10 บาท)</label>
    </div>
</div>
<div class="form-group mt-2">
    <label for="note">หมายเหตุ (ถ้ามี)</label>
    <textarea class="form-control" id="note" name="note" rows="2" placeholder="กรุณากรอกหมายเหตุ..."></textarea>
</div>
<div class="modal-footer">
    <button type="submit" name="add_to_cart" class="btn btn-success">เพิ่มลงตะกร้า</button>
    <button type="button" class="btn btn-secondary" data-dismiss="modal">ยกเลิก</button>
</div>

            </form>
        </div>
    </div>
</div>


</body>
</html>
