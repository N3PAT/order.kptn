<?php

header('Content-Type: text/plain');

readfile('line_event_log.txt');

?>